# MENINE GARDEN HRMS

ระบบต้นแบบ MENINE GARDEN HRMS พร้อมใช้งานบน GitHub

## โครงสร้าง

- `lib/main.dart` — Flutter Mobile App
- `server/server.js` — Node.js API Backend
- `server/middleware/auth-middleware.js` — JWT Auth Middleware
- `server/test-requests.http` — ตัวอย่างทดสอบ API
- `pubspec.yaml` — Flutter dependencies

## วิธีรัน Backend

```bash
cd server
npm install
npm start
```

เปิด API ที่:

```text
http://localhost:3000/api/health
```

## วิธีรัน Flutter

```bash
flutter pub get
flutter run
```

## Login ทดสอบ

```text
MN006 / 123456
ADMIN / 0000
```
