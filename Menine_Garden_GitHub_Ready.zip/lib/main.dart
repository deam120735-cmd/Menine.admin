import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const GardenHRApp());

class GardenHRApp extends StatelessWidget {
  const GardenHRApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: const Color(0xfff5f5f5),
      ),
      home: const MobileLoginScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int selectedIndex = 0;

  final List<Widget> screens = const [
    TimeTrackingScreen(),
    WorkReportScreen(),
    RequestLeaveOTScreen(),
    PayrollScreen(),
    EmployeeManagerScreen(),
    ApprovalCenterScreen(),
    EquipmentStockScreen(),
    InventoryAndPayslipScreen(),
    DailyReportAndHistoryScreen(),
    ShiftAndWarningScreen(),
  ];

  final List<BottomNavigationBarItem> navItems = const [
    BottomNavigationBarItem(icon: Icon(Icons.timer), label: 'ลงเวลา'),
    BottomNavigationBarItem(icon: Icon(Icons.photo_library), label: 'ส่งงาน'),
    BottomNavigationBarItem(icon: Icon(Icons.edit_document), label: 'ลา/OT'),
    BottomNavigationBarItem(icon: Icon(Icons.payments), label: 'เงินเดือน'),
    BottomNavigationBarItem(icon: Icon(Icons.people), label: 'พนักงาน'),
    BottomNavigationBarItem(icon: Icon(Icons.approval), label: 'อนุมัติ'),
    BottomNavigationBarItem(icon: Icon(Icons.inventory_2), label: 'คลัง'),
    BottomNavigationBarItem(icon: Icon(Icons.receipt), label: 'เบิก/สลิป'),
    BottomNavigationBarItem(icon: Icon(Icons.assignment), label: 'รายงานฉัน'),
    BottomNavigationBarItem(icon: Icon(Icons.schedule), label: 'กะ/เตือน'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        selectedItemColor: Colors.green[800],
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        selectedFontSize: 11,
        unselectedFontSize: 10,
        onTap: (index) => setState(() => selectedIndex = index),
        items: navItems,
      ),
    );
  }
}

class MobileLoginScreen extends StatefulWidget {
  const MobileLoginScreen({super.key});

  @override
  State<MobileLoginScreen> createState() => _MobileLoginScreenState();
}

class _MobileLoginScreenState extends State<MobileLoginScreen> {
  final empIdController = TextEditingController();
  final passwordController = TextEditingController();
  bool isLoading = false;
  bool obscurePassword = true;

  void handleLogin() async {
    final empId = empIdController.text.trim();
    final password = passwordController.text.trim();

    if (empId.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('❌ กรุณากรอกรหัสพนักงานและรหัสผ่านให้ครบถ้วน'),
        backgroundColor: Colors.red,
      ));
      return;
    }

    setState(() => isLoading = true);
    await Future.delayed(const Duration(milliseconds: 700));
    setState(() => isLoading = false);

    if ((empId == 'EMP001' && password == '123456') ||
        (empId == 'MN005' && password == '123456') ||
        (empId == 'MN006' && password == '123456') ||
        (empId == 'ADMIN' && password == '0000')) {
      debugPrint('JWT TOKEN: mock_jwt_token_menine_garden_2026');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('🔒 ยืนยันตัวตนสำเร็จ!'),
        backgroundColor: Colors.green,
      ));
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainNavigationScreen()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('❌ รหัสพนักงานหรือรหัสผ่านไม่ถูกต้อง'),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  void dispose() {
    empIdController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Icon(Icons.forest_rounded, size: 90, color: Colors.green[700]),
              const SizedBox(height: 16),
              Text('MENINE GARDEN HR', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.green[900], letterSpacing: 1.2)),
              const Text('ระบบบันทึกเวลาและสลิปเงินเดือนคนสวน', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: Colors.grey)),
              const SizedBox(height: 40),
              TextField(controller: empIdController, decoration: InputDecoration(labelText: 'รหัสพนักงาน เช่น MN006', prefixIcon: const Icon(Icons.person), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), fillColor: Colors.white, filled: true)),
              const SizedBox(height: 16),
              TextField(controller: passwordController, obscureText: obscurePassword, decoration: InputDecoration(labelText: 'รหัสผ่าน', prefixIcon: const Icon(Icons.lock), suffixIcon: IconButton(icon: Icon(obscurePassword ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => obscurePassword = !obscurePassword)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), fillColor: Colors.white, filled: true)),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: isLoading ? null : handleLogin, style: ElevatedButton.styleFrom(backgroundColor: Colors.green[700], foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: isLoading ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3)) : const Text('เข้าสู่ระบบทำงาน', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              const SizedBox(height: 16),
              const Text('ทดสอบ: MN006 / 123456 หรือ ADMIN / 0000', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}

class TimeTrackingScreen extends StatefulWidget {
  const TimeTrackingScreen({super.key});
  @override
  State<TimeTrackingScreen> createState() => _TimeTrackingScreenState();
}

class _TimeTrackingScreenState extends State<TimeTrackingScreen> {
  String currentLocation = 'กำลังตรวจสอบ GPS...';
  bool isInRange = false;
  String currentTime = '';
  bool isCheckedIn = false;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() {
        currentLocation = '📍 พิกัด: MENINE GARDEN อยู่ในพื้นที่ทำงาน';
        isInRange = true;
      });
    });
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      final now = DateTime.now();
      if (!mounted) return;
      setState(() => currentTime = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}');
    });
  }

  void handleTimeLog(String type) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.location_on, size: 50, color: Colors.green),
        title: Text('ยืนยัน GPS เพื่อบันทึกเวลา$type'),
        content: const Text('ระบบกำลังตรวจสอบตำแหน่งหน้างาน...'),
        actions: [TextButton(onPressed: () { Navigator.pop(context); setState(() => isCheckedIn = type == 'เข้างาน'); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('✅ บันทึกเวลา$type สำเร็จ ส่งเข้า Payroll แล้ว'), backgroundColor: Colors.green)); }, child: const Text('ตกลง'))],
      ),
    );
  }

  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ลงเวลาคนสวน', style: TextStyle(color: Colors.white)), backgroundColor: Colors.green[700], centerTitle: true),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Card(child: ListTile(leading: const CircleAvatar(child: Text('MN006')), title: const Text('นายกิตติพงษ์ แจ่มจำรัส'), subtitle: const Text('ตำแหน่ง: คนสวน'), trailing: Chip(label: Text(isCheckedIn ? 'เข้างานแล้ว' : 'ยังไม่เข้างาน'), backgroundColor: isCheckedIn ? Colors.green[100] : Colors.orange[100]))),
          const SizedBox(height: 20),
          Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [const Text('เวลาปัจจุบัน'), Text(currentTime, style: TextStyle(fontSize: 46, fontWeight: FontWeight.bold, color: Colors.green[800]))]))),
          const SizedBox(height: 20),
          Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: isInRange ? Colors.green[50] : Colors.amber[50], borderRadius: BorderRadius.circular(10), border: Border.all(color: isInRange ? Colors.green : Colors.amber)), child: Text(currentLocation, style: const TextStyle(fontWeight: FontWeight.bold))),
          const SizedBox(height: 30),
          ElevatedButton.icon(onPressed: isInRange ? () => handleTimeLog('เข้างาน') : null, icon: const Icon(Icons.login), label: const Padding(padding: EdgeInsets.all(16), child: Text('กดลงเวลาเข้างาน', style: TextStyle(fontSize: 20))), style: ElevatedButton.styleFrom(backgroundColor: Colors.green[700], foregroundColor: Colors.white)),
          const SizedBox(height: 15),
          ElevatedButton.icon(onPressed: isInRange ? () => handleTimeLog('ออกงาน') : null, icon: const Icon(Icons.logout), label: const Padding(padding: EdgeInsets.all(16), child: Text('กดลงเวลาออกงาน', style: TextStyle(fontSize: 20))), style: ElevatedButton.styleFrom(backgroundColor: Colors.red[600], foregroundColor: Colors.white)),
        ]),
      ),
    );
  }
}

class WorkReportScreen extends StatefulWidget { const WorkReportScreen({super.key}); @override State<WorkReportScreen> createState() => _WorkReportScreenState(); }
class _WorkReportScreenState extends State<WorkReportScreen> {
  bool hasBeforePhoto = false, hasAfterPhoto = false;
  String selectedHouse = 'A1', selectedJob = 'รดน้ำ';
  final detailController = TextEditingController();
  final houses = ['A1','A2','A3','B1','B2','B3','B4','B5','ฉันทะ','คุณนุ่น','คุณเลย์','KD99'];
  final jobs = ['รดน้ำ','ถอนวัชพืช','ตัดหญ้า','ตัดแต่ง','ใส่ปุ๋ย','ฉีดยา','QC ปิดงาน'];
  void submitReport(){ if(!hasBeforePhoto||!hasAfterPhoto){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('❌ กรุณาอัพโหลดรูปก่อนทำและหลังทำ'),backgroundColor: Colors.red));return;} ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('✅ ส่งรายงาน $selectedHouse / $selectedJob เรียบร้อย'),backgroundColor: Colors.green)); setState((){hasBeforePhoto=false;hasAfterPhoto=false;detailController.clear();}); }
  @override void dispose(){detailController.dispose(); super.dispose();}
  Widget photoBox(String title,bool hasPhoto,VoidCallback onTap)=>Expanded(child:GestureDetector(onTap:onTap,child:Container(height:150,decoration:BoxDecoration(color:Colors.grey[300],borderRadius:BorderRadius.circular(10),border:Border.all(color:hasPhoto?Colors.green:Colors.transparent,width:2)),child:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(hasPhoto?Icons.check_circle:Icons.add_a_photo,color:hasPhoto?Colors.green:Colors.black,size:40),Text(hasPhoto?'มีรูปแล้ว':title)])))));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('รายงานการทำงาน',style:TextStyle(color:Colors.white)),backgroundColor:Colors.green[700],centerTitle:true),body:SingleChildScrollView(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[DropdownButtonFormField(value:selectedHouse,decoration:const InputDecoration(labelText:'เลือกบ้าน/โซน',border:OutlineInputBorder()),items:houses.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>selectedHouse=v!)),const SizedBox(height:15),DropdownButtonFormField(value:selectedJob,decoration:const InputDecoration(labelText:'เลือกงาน',border:OutlineInputBorder()),items:jobs.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>selectedJob=v!)),const SizedBox(height:20),Row(children:[photoBox('รูปก่อนทำ',hasBeforePhoto,()=>setState(()=>hasBeforePhoto=true)),const SizedBox(width:15),photoBox('รูปหลังทำ',hasAfterPhoto,()=>setState(()=>hasAfterPhoto=true))]),const SizedBox(height:20),TextField(controller:detailController,maxLines:3,decoration:const InputDecoration(hintText:'รายละเอียดงาน เช่น ตัดแต่งกิ่ง ถอนหญ้า QC แล้ว',border:OutlineInputBorder())),const SizedBox(height:25),ElevatedButton(onPressed:submitReport,style:ElevatedButton.styleFrom(backgroundColor:Colors.green[700],padding:const EdgeInsets.all(15)),child:const Text('ส่งรายงานให้หัวหน้าตรวจ',style:TextStyle(color:Colors.white,fontSize:18)))])));
}

class RequestLeaveOTScreen extends StatefulWidget { const RequestLeaveOTScreen({super.key}); @override State<RequestLeaveOTScreen> createState()=>_RequestLeaveOTScreenState(); }
class _RequestLeaveOTScreenState extends State<RequestLeaveOTScreen>{ String selectedLeaveType='ป่วย'; final leaveTypes=['ป่วย','ลากิจธุระราชการ','ลากิจหักเงิน','ลาพักร้อน']; final otHoursController=TextEditingController(); @override void dispose(){otHoursController.dispose();super.dispose();} void submitLeave()=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('📝 ส่งใบลา $selectedLeaveType แล้ว รออนุมัติ'),backgroundColor:Colors.orange[800])); void submitOT(){if(otHoursController.text.isEmpty)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('⏰ ขอ OT ${otHoursController.text} ชม. แล้ว'),backgroundColor:Colors.blue[800]));otHoursController.clear();} @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('ขอลา / ขอ OT',style:TextStyle(color:Colors.white)),backgroundColor:Colors.green[700],centerTitle:true),body:SingleChildScrollView(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Card(color:Colors.orange[50],child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('📬 ยื่นใบลาออนไลน์',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),DropdownButton<String>(value:selectedLeaveType,isExpanded:true,items:leaveTypes.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>selectedLeaveType=v!)),ElevatedButton(onPressed:submitLeave,style:ElevatedButton.styleFrom(backgroundColor:Colors.orange[700]),child:const Text('ส่งใบลา',style:TextStyle(color:Colors.white)))]))),const SizedBox(height:20),Card(color:Colors.blue[50],child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('⏰ ขออนุมัติทำ OT',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),TextField(controller:otHoursController,keyboardType:TextInputType.number,decoration:const InputDecoration(hintText:'จำนวนชั่วโมง เช่น 2',border:OutlineInputBorder())),const SizedBox(height:15),ElevatedButton(onPressed:submitOT,style:ElevatedButton.styleFrom(backgroundColor:Colors.blue[700]),child:const Text('ส่งคำขอ OT',style:TextStyle(color:Colors.white)))])))])));
}

class PayrollScreen extends StatelessWidget { const PayrollScreen({super.key}); @override Widget build(BuildContext context){ final employee=EmployeePayroll(id:'EMP001',fullName:'นายสมชาย ใจดี',baseSalary:15000,allowance:1000); final timeLogs=[TimeLogPayroll(date:'2026-06-02',status:'late',lateMinutes:15),TimeLogPayroll(date:'2026-06-05',status:'incomplete'),TimeLogPayroll(date:'2026-06-10',status:'normal',otStatus:'approved',otHours:2)]; final leaveRequests=[LeaveRequestPayroll(leaveType:'sick',totalDays:4,hasMedicalCertificate:false,status:'approved')]; final payroll=calculatePayroll(employee:employee,timeLogs:timeLogs,leaveRequests:leaveRequests); final earnings=payroll['earnings']; final deductions=payroll['deductions']; return Scaffold(appBar:AppBar(title:const Text('สรุปเงินเดือน',style:TextStyle(color:Colors.white)),backgroundColor:Colors.green[700],centerTitle:true),body:ListView(padding:const EdgeInsets.all(20),children:[Card(child:ListTile(leading:const CircleAvatar(child:Text('MN')),title:Text(payroll['employee_name']),subtitle:Text('รหัส: ${payroll['employee_id']}'))),const SizedBox(height:15),Card(color:Colors.green[50],child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('รายรับ',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text('เงินเดือนครึ่งงวด: ${earnings['base_salary_half'].toStringAsFixed(2)} บาท'),Text('สวัสดิการครึ่งงวด: ${earnings['allowance_half'].toStringAsFixed(2)} บาท'),Text('ค่า OT: ${earnings['ot_pay'].toStringAsFixed(2)} บาท'),Text('รวมรายรับ: ${earnings['total_earnings'].toStringAsFixed(2)} บาท')]))),Card(color:Colors.red[50],child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('รายการหัก',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text('มาสาย: ${deductions['late'].toStringAsFixed(2)} บาท'),Text('ลงเวลาไม่ครบ: ${deductions['incomplete'].toStringAsFixed(2)} บาท'),Text('ขาดงาน: ${deductions['absent'].toStringAsFixed(2)} บาท'),Text('ลาแบบหักเงิน: ${deductions['leave'].toStringAsFixed(2)} บาท'),Text('ประกันสังคม: ${deductions['social_security'].toStringAsFixed(2)} บาท'),Text('รวมรายการหัก: ${deductions['total_deductions'].toStringAsFixed(2)} บาท')]))),Card(color:Colors.blue[50],child:Padding(padding:const EdgeInsets.all(20),child:Center(child:Text('เงินสุทธิ: ${payroll['net_pay'].toStringAsFixed(2)} บาท',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold))))),const SizedBox(height:20),Card(child:Padding(padding:const EdgeInsets.all(15),child:SelectableText(payroll.toString(),style:const TextStyle(fontFamily:'monospace',fontSize:12))))])); }}

class EmployeePayroll{final String id;final String fullName;final double baseSalary;final double allowance;EmployeePayroll({required this.id,required this.fullName,required this.baseSalary,required this.allowance});}
class TimeLogPayroll{final String date;final String status;final int lateMinutes;final String otStatus;final double otHours;TimeLogPayroll({this.date='',required this.status,this.lateMinutes=0,this.otStatus='',this.otHours=0});}
class LeaveRequestPayroll{final String status;final String leaveType;final double totalDays;final bool hasMedicalCertificate;LeaveRequestPayroll({required this.status,required this.leaveType,required this.totalDays,this.hasMedicalCertificate=false});}
Map<String,dynamic> calculatePayroll({required EmployeePayroll employee,required List<TimeLogPayroll> timeLogs,required List<LeaveRequestPayroll> leaveRequests}){final baseSalaryPerPeriod=employee.baseSalary/2;final allowancePerPeriod=employee.allowance/2;final dailyRate=employee.baseSalary/30;const minuteRate=1.0;double totalOTEarnings=0,lateDeduction=0,incompleteDeduction=0,absentDeduction=0,leaveDeduction=0;for(final log in timeLogs){if(log.status=='late'&&log.lateMinutes>0){lateDeduction+=log.lateMinutes*minuteRate;}else if(log.status=='incomplete'){incompleteDeduction+=dailyRate/2;}else if(log.status=='absent'){absentDeduction+=dailyRate;}}for(final leave in leaveRequests){if(leave.status=='approved'){if(leave.leaveType=='sick'){if(leave.totalDays>=3&&!leave.hasMedicalCertificate){leaveDeduction+=(leave.totalDays-3)*dailyRate;}}else if(leave.leaveType=='business_unpaid'||leave.leaveType=='other_unpaid'){leaveDeduction+=leave.totalDays*dailyRate;}}}final otRatePerHour=(dailyRate/8)*1.5;for(final log in timeLogs){if(log.otStatus=='approved'&&log.otHours>0){totalOTEarnings+=log.otHours*otRatePerHour;}}final socialSecurityDeduction=(baseSalaryPerPeriod*0.05)>375?375.0:baseSalaryPerPeriod*0.05;final totalEarnings=baseSalaryPerPeriod+allowancePerPeriod+totalOTEarnings;final totalDeductions=lateDeduction+incompleteDeduction+absentDeduction+leaveDeduction+socialSecurityDeduction;return {'employee_id':employee.id,'employee_name':employee.fullName,'earnings':{'base_salary_half':baseSalaryPerPeriod,'allowance_half':allowancePerPeriod,'ot_pay':totalOTEarnings,'total_earnings':totalEarnings},'deductions':{'late':lateDeduction,'incomplete':incompleteDeduction,'absent':absentDeduction,'leave':leaveDeduction,'social_security':socialSecurityDeduction,'total_deductions':totalDeductions},'net_pay':totalEarnings-totalDeductions};}

class EmployeeData{final String id;final String name;final String position;final DateTime startDate;String status;EmployeeData({required this.id,required this.name,required this.position,required this.startDate,required this.status});}
class EmployeeManagerScreen extends StatefulWidget{const EmployeeManagerScreen({super.key});@override State<EmployeeManagerScreen> createState()=>_EmployeeManagerScreenState();}
class _EmployeeManagerScreenState extends State<EmployeeManagerScreen>{final employees=[EmployeeData(id:'EMP001',name:'นายสมชาย ใจดี',position:'คนสวน โซน A',startDate:DateTime(2026,3,1),status:'probation'),EmployeeData(id:'EMP002',name:'นายสมศักดิ์ ขยันยิ่ง',position:'คนสวน โซน B',startDate:DateTime(2026,5,15),status:'probation'),EmployeeData(id:'EMP003',name:'นางสาวสมศรี ร่มเย็น',position:'เจ้าหน้าที่ HR',startDate:DateTime(2025,1,10),status:'regular')];Map<String,dynamic> calculateProbationDays(DateTime startDate){final endDate=startDate.add(const Duration(days:119));final diff=endDate.difference(DateTime.now()).inDays;return {'endDate':endDate,'daysLeft':diff>0?diff:0,'isOver':diff<=0};}String formatThaiDate(DateTime d)=>'${d.day}/${d.month}/${d.year+543}';@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('ทะเบียนพนักงาน',style:TextStyle(color:Colors.white)),backgroundColor:Colors.green[700]),body:ListView.builder(padding:const EdgeInsets.all(15),itemCount:employees.length,itemBuilder:(_,i){final emp=employees[i];final p=calculateProbationDays(emp.startDate);return Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${emp.id} / ${emp.name}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text('ตำแหน่ง: ${emp.position}'),Text('วันเริ่มงาน: ${formatThaiDate(emp.startDate)}'),Text('ครบทดลองงาน: ${formatThaiDate(p['endDate'])}'),Chip(label:Text(emp.status=='regular'?'พนักงานประจำ':p['isOver']?'ครบ 119 วันแล้ว':'ทดลองงาน เหลือ ${p['daysLeft']} วัน')),if(emp.status=='probation'&&p['isOver'])ElevatedButton(onPressed:()=>setState(()=>emp.status='regular'),child:const Text('ปรับเป็นประจำ'))])));}),floatingActionButton:FloatingActionButton.extended(onPressed:(){},icon:const Icon(Icons.add),label:const Text('เพิ่มพนักงาน'),backgroundColor:Colors.green[700],foregroundColor:Colors.white));}

class ApprovalRequest{final String id,name,type,detail,duration,attachment,date;ApprovalRequest({required this.id,required this.name,required this.type,required this.detail,required this.duration,required this.attachment,required this.date});}
class ApprovalCenterScreen extends StatefulWidget{const ApprovalCenterScreen({super.key});@override State<ApprovalCenterScreen> createState()=>_ApprovalCenterScreenState();}
class _ApprovalCenterScreenState extends State<ApprovalCenterScreen>{final requests=[ApprovalRequest(id:'REQ001',name:'นายสมชาย ใจดี',type:'ลาป่วย',detail:'ปวดหัวเป็นไข้ตัวร้อน',duration:'3 วัน',attachment:'มีใบรับรองแพทย์',date:'2026-06-05'),ApprovalRequest(id:'REQ002',name:'นายสมศักดิ์ ขยันยิ่ง',type:'ลาธุระอื่นๆ หักเงิน',detail:'ไปทำธุระที่ต่างจังหวัด',duration:'1 วัน',attachment:'ไม่มี',date:'2026-06-06'),ApprovalRequest(id:'REQ003',name:'นายสมชาย ใจดี',type:'ขอโอที OT',detail:'เคลียร์หญ้าโซน C ตกค้าง',duration:'2 ชั่วโมง',attachment:'มีรูปถ่ายหน้างาน',date:'2026-06-07')];void action(ApprovalRequest r,String a){setState(()=>requests.removeWhere((x)=>x.id==r.id));ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${a=='approve'?'อนุมัติ':'ปฏิเสธ'} คำขอ ${r.id} แล้ว'),backgroundColor:a=='approve'?Colors.green:Colors.red));}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('ศูนย์อนุมัติคำขอ',style:TextStyle(color:Colors.white)),backgroundColor:Colors.green[700]),body:requests.isEmpty?const Center(child:Text('🎉 ไม่มีคำขอค้างคาในระบบ')):ListView.builder(padding:const EdgeInsets.all(15),itemCount:requests.length,itemBuilder:(_,i){final r=requests[i];final color=(r.type.contains('OT')||r.type.contains('โอที'))?Colors.blue:Colors.orange;return Card(child:Container(decoration:BoxDecoration(border:Border(left:BorderSide(color:color,width:5))),padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(r.name,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Chip(label:Text(r.type),backgroundColor:color.withOpacity(.12),labelStyle:TextStyle(color:color)),Text('เหตุผล: ${r.detail}'),Text('วันที่แจ้ง: ${r.date}'),Text('จำนวน: ${r.duration}'),Text('หลักฐาน: ${r.attachment}'),const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton(onPressed:()=>action(r,'reject'),child:const Text('ปฏิเสธ'))),const SizedBox(width:10),Expanded(child:ElevatedButton(onPressed:()=>action(r,'approve'),style:ElevatedButton.styleFrom(backgroundColor:Colors.green[700],foregroundColor:Colors.white),child:const Text('อนุมัติ')))])]))); }));}

class EquipmentItem{final String id;final String itemName;int qty;final String unit;EquipmentItem({required this.id,required this.itemName,required this.qty,required this.unit});}
class AccountingRecord{final String transactionId,type,category,description,date;final double amount;AccountingRecord({required this.transactionId,required this.type,required this.category,required this.amount,required this.description,required this.date});@override String toString()=>'$transactionId $amount $description';}
List<EquipmentItem> equipmentStock=[EquipmentItem(id:'EQ001',itemName:'ปุ๋ยเคมีสูตร 16-16-16',qty:50,unit:'กระสอบ'),EquipmentItem(id:'EQ002',itemName:'กรรไกรตัดกิ่งไม้',qty:5,unit:'อัน')];List<AccountingRecord> accountingRecords=[];
Map<String,dynamic> approveEquipmentRequest({required String requestId,required String itemId,required int requestedQty}){try{final item=equipmentStock.firstWhere((e)=>e.id==itemId);if(item.qty<requestedQty){return {'status':'failed','message':'❌ ${item.itemName} คงเหลือ ${item.qty} ${item.unit} ไม่เพียงพอ'};}item.qty-=requestedQty;return {'status':'success','message':'✅ อนุมัติคำขอ $requestId สำเร็จ! ตัดยอดคลัง ${item.itemName} ออกแล้ว $requestedQty ${item.unit}. (คงเหลือในคลัง: ${item.qty})'};}catch(e){return {'status':'failed','message':'ไม่พบสินค้าในคลัง'};}}
Map<String,dynamic> approveCashRequest({required String requestId,required String employeeId,required double amount,required String reason}){final record=AccountingRecord(transactionId:'TXN_${DateTime.now().millisecondsSinceEpoch}',type:'expense',category:'ซื้อของหน้างานด่วน',amount:amount,description:'เบิกเงินสดโดยพนักงาน $employeeId เพื่อ $reason',date:DateTime.now().toString().split(' ')[0]);accountingRecords.add(record);return {'status':'success','message':'💵 อนุมัติเงินสด ${amount.toStringAsFixed(0)} บาท สำเร็จ! ระบบบันทึกลงบัญชีรายจ่ายของบริษัทแล้ว','accounting_record':record};}
class EquipmentStockScreen extends StatefulWidget{const EquipmentStockScreen({super.key});@override State<EquipmentStockScreen> createState()=>_EquipmentStockScreenState();}
class _EquipmentStockScreenState extends State<EquipmentStockScreen>{@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('คลังอุปกรณ์สวน',style:TextStyle(color:Colors.white)),backgroundColor:Colors.green[700]),body:ListView.builder(itemCount:equipmentStock.length,itemBuilder:(_,i){final item=equipmentStock[i];return Card(margin:const EdgeInsets.all(10),child:ListTile(leading:CircleAvatar(backgroundColor:Colors.green[100],child:const Icon(Icons.inventory)),title:Text(item.itemName),subtitle:Text('รหัส ${item.id}'),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text('${item.qty}',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)),Text(item.unit)])));}),floatingActionButton:FloatingActionButton.extended(backgroundColor:Colors.green,onPressed:(){final r=approveEquipmentRequest(requestId:'REQ-EQ-99',itemId:'EQ001',requestedQty:2);setState((){});ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r['message'])));},icon:const Icon(Icons.remove_circle),label:const Text('เบิกตัวอย่าง')));}

class InventoryAndPayslipScreen extends StatefulWidget{const InventoryAndPayslipScreen({super.key});@override State<InventoryAndPayslipScreen> createState()=>_InventoryAndPayslipScreenState();}
class _InventoryAndPayslipScreenState extends State<InventoryAndPayslipScreen>{final cashController=TextEditingController();final reasonController=TextEditingController();String selectedEquipment='ปุ๋ยเคมีสูตร 16-16-16';final equipmentList=['ปุ๋ยเคมีสูตร 16-16-16','กรรไกรตัดกิ่งไม้','จอบขุดดิน','น้ำยาเร่งราก'];@override void dispose(){cashController.dispose();reasonController.dispose();super.dispose();}Widget buildRowItem(String title,String amount){final minus=amount.contains('-');return Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(title),Text(amount,style:TextStyle(fontWeight:FontWeight.bold,color:minus?Colors.red:Colors.black87))]));}Widget reqTab()=>SingleChildScrollView(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Card(elevation:3,child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('🛠️ ขอเบิกเครื่องมือ / อุปกรณ์',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold,color:Colors.green[800])),const SizedBox(height:10),DropdownButtonFormField<String>(value:selectedEquipment,items:equipmentList.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>selectedEquipment=v!),decoration:const InputDecoration(border:OutlineInputBorder(),filled:true,fillColor:Colors.white)),const SizedBox(height:12),ElevatedButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('📦 ส่งคำขอเบิก [$selectedEquipment] แล้ว รอแอดมินตัดคลัง'),backgroundColor:Colors.green)),style:ElevatedButton.styleFrom(backgroundColor:Colors.green[700],minimumSize:const Size.fromHeight(45)),child:const Text('ส่งคำขอเบิกอุปกรณ์',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold)))]))),const SizedBox(height:20),Card(elevation:3,color:Colors.blue[50],child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('💵 ขอเบิกเงินสดซื้อของด่วน',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold,color:Colors.blue[900])),const SizedBox(height:10),TextField(controller:cashController,keyboardType:TextInputType.number,decoration:const InputDecoration(hintText:'ระบุจำนวนเงิน (บาท)',border:OutlineInputBorder(),filled:true,fillColor:Colors.white,prefixText:'฿ ')),const SizedBox(height:10),TextField(controller:reasonController,decoration:const InputDecoration(hintText:'เหตุผล เช่น ซื้อสายยางฉีดน้ำด่วน',border:OutlineInputBorder(),filled:true,fillColor:Colors.white)),const SizedBox(height:12),ElevatedButton(onPressed:(){if(cashController.text.isEmpty||reasonController.text.isEmpty)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('💰 ส่งคำขอเบิกเงินสด ${cashController.text} บาท เรียบร้อย'),backgroundColor:Colors.blue[800]));cashController.clear();reasonController.clear();},style:ElevatedButton.styleFrom(backgroundColor:Colors.blue[700],minimumSize:const Size.fromHeight(45)),child:const Text('ส่งคำขอเบิกเงินสด',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold)))])))]));Widget payslipTab()=>SingleChildScrollView(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.grey[200],borderRadius:BorderRadius.circular(8)),child:const Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('งวดล่าสุด:',style:TextStyle(fontWeight:FontWeight.bold)),Text('วิก 1 (1 - 15 มิ.ย. 2026)',style:TextStyle(color:Colors.green,fontWeight:FontWeight.bold))])),const SizedBox(height:15),const Text('➕ รายรับ',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold,color:Colors.green)),const Divider(),buildRowItem('ฐานเงินเดือนครึ่งงวด','฿ 7,500.00'),buildRowItem('ค่าสวัสดิการพนักงาน','฿ 500.00'),buildRowItem('เงินค่าล่วงเวลา OT','฿ 625.00'),const SizedBox(height:15),const Text('➖ รายจ่าย / ส่วนหัก',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold,color:Colors.red)),const Divider(),buildRowItem('หักมาสาย 35 นาที','- ฿ 35.00'),buildRowItem('หักลงเวลาไม่ครบ / มาครึ่งวัน','- ฿ 250.00'),buildRowItem('หักประกันสังคม','- ฿ 375.00'),const SizedBox(height:20),Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.green[50],borderRadius:BorderRadius.circular(10),border:Border.all(color:Colors.green)),child:const Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('💰 เงินสุทธิ:',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold,color:Colors.green)),Text('฿ 7,465.00',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:Colors.green))]))]));@override Widget build(BuildContext context)=>DefaultTabController(length:2,child:Scaffold(appBar:AppBar(title:const Text('เบิกของ & สลิปเงินเดือน',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),backgroundColor:Colors.green[700],bottom:const TabBar(labelColor:Colors.white,unselectedLabelColor:Colors.white70,indicatorColor:Colors.white,tabs:[Tab(icon:Icon(Icons.shopping_bag),text:'ขอเบิก'),Tab(icon:Icon(Icons.receipt_long),text:'สลิป')]),),body:TabBarView(children:[reqTab(),payslipTab()])));}

class DailyReportAndHistoryScreen extends StatefulWidget{const DailyReportAndHistoryScreen({super.key});@override State<DailyReportAndHistoryScreen> createState()=>_DailyReportAndHistoryScreenState();}
class _DailyReportAndHistoryScreenState extends State<DailyReportAndHistoryScreen> with SingleTickerProviderStateMixin{late TabController tab;final myTimeHistory=[{'date':'05 มิ.ย. 2026','in':'07:55','out':'17:01','status':'ปกติ','color':Colors.green},{'date':'04 มิ.ย. 2026','in':'08:15','out':'17:00','status':'สาย 15 นาที','color':Colors.amber},{'date':'03 มิ.ย. 2026','in':'07:50','out':'--:--','status':'ลงเวลาไม่ครบ','color':Colors.orange},{'date':'02 มิ.ย. 2026','in':'--:--','out':'--:--','status':'ขาดงาน / ขาดสแกน','color':Colors.red}];bool hasBefore=false,hasAfter=false;final detailController=TextEditingController();@override void initState(){super.initState();tab=TabController(length:2,vsync:this);}@override void dispose(){tab.dispose();detailController.dispose();super.dispose();}Widget photo(String label,IconData icon,bool before){final has=before?hasBefore:hasAfter;return Expanded(child:GestureDetector(onTap:()=>setState(()=>before?hasBefore=true:hasAfter=true),child:Container(height:145,decoration:BoxDecoration(color:has?Colors.green[50]:Colors.grey[200],borderRadius:BorderRadius.circular(12),border:Border.all(color:has?Colors.green:Colors.grey,width:2)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(has?Icons.check_circle:icon,size:42,color:has?Colors.green:Colors.grey[700]),const SizedBox(height:8),Text(has?'อัปโหลดแล้ว':label,textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.bold))]))));}Widget reportTab()=>SingleChildScrollView(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('📸 ถ่ายรูปรายงานหัวหน้า',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:15),Row(children:[photo('รูปก่อนทำ\nBefore',Icons.add_a_photo,true),const SizedBox(width:15),photo('รูปหลังทำ\nAfter',Icons.check_circle_outline,false)]),const SizedBox(height:25),TextField(controller:detailController,maxLines:4,decoration:const InputDecoration(labelText:'รายละเอียดงาน',hintText:'เช่น ถอนวัชพืชโซน A1 / ตัดแต่งพุ่ม / QC ปิดบ้าน',border:OutlineInputBorder())),const SizedBox(height:25),ElevatedButton.icon(onPressed:(){if(!hasBefore||!hasAfter){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('กรุณาเพิ่มรูปก่อนทำและหลังทำ'),backgroundColor:Colors.red));return;}ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('ส่งรายงานเรียบร้อย'),backgroundColor:Colors.green));},icon:const Icon(Icons.send),label:const Text('ส่งรายงานงานวันนี้'),style:ElevatedButton.styleFrom(backgroundColor:Colors.green[700],foregroundColor:Colors.white,padding:const EdgeInsets.all(15)))]));Widget historyTab()=>ListView.builder(padding:const EdgeInsets.all(15),itemCount:myTimeHistory.length,itemBuilder:(_,i){final item=myTimeHistory[i];final color=item['color'] as Color;return Card(margin:const EdgeInsets.only(bottom:12),child:ListTile(leading:CircleAvatar(backgroundColor:color.withOpacity(.15),child:Icon(Icons.access_time,color:color)),title:Text(item['date'].toString()),subtitle:Text('เข้า: ${item['in']} | ออก: ${item['out']}'),trailing:Chip(label:Text(item['status'].toString()),backgroundColor:color.withOpacity(.15),labelStyle:TextStyle(color:color,fontWeight:FontWeight.bold))));});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('รายงาน & ประวัติตัวเอง',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),backgroundColor:Colors.green[700],bottom:TabBar(controller:tab,labelColor:Colors.white,unselectedLabelColor:Colors.white70,indicatorColor:Colors.white,tabs:const[Tab(icon:Icon(Icons.photo_camera),text:'ส่งรายงาน'),Tab(icon:Icon(Icons.history),text:'ประวัติเวลา')])),body:TabBarView(controller:tab,children:[reportTab(),historyTab()]));}

class StaffShiftData{final String id,name,position;String currentShift;int warnings;StaffShiftData({required this.id,required this.name,required this.position,required this.currentShift,required this.warnings});}
class ShiftAndWarningScreen extends StatefulWidget{const ShiftAndWarningScreen({super.key});@override State<ShiftAndWarningScreen> createState()=>_ShiftAndWarningScreenState();}
class _ShiftAndWarningScreenState extends State<ShiftAndWarningScreen>{final staffList=[StaffShiftData(id:'EMP001',name:'นายสมชาย ใจดี',position:'คนสวน โซน A',currentShift:'กะเช้า 08:00 - 17:00',warnings:0),StaffShiftData(id:'EMP002',name:'นายสมศักดิ์ ขยันยิ่ง',position:'คนสวน โซน B',currentShift:'กะบ่าย 13:00 - 22:00',warnings:1)];String? selectedEmp;String offenseType='มาสายซ้ำซาก';final descriptionController=TextEditingController();final shifts=['กะเช้า 08:00 - 17:00','กะบ่าย 13:00 - 22:00','กะพิเศษ 06:00 - 15:00'];final offenses=['มาสายซ้ำซาก','ละทิ้งหน้าที่ / ออกนอกพิกัดสวน','ทำอุปกรณ์หรือต้นไม้ลูกค้าเสียหาย','อื่นๆ'];@override void dispose(){descriptionController.dispose();super.dispose();}Color warningColor(int count)=>count==0?Colors.green:count==1?Colors.orange:Colors.red;@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('จัดกะ / ใบเตือน',style:TextStyle(color:Colors.white)),backgroundColor:Colors.green[700]),body:ListView(padding:const EdgeInsets.all(15),children:[const Text('📅 จัดกะการทำงานพนักงาน',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),...staffList.map((s)=>Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(s.name,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text(s.position),Text('กะปัจจุบัน: ${s.currentShift}'),const SizedBox(height:10),DropdownButtonFormField<String>(decoration:const InputDecoration(labelText:'เปลี่ยนกะ',border:OutlineInputBorder()),value:s.currentShift,items:shifts.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>s.currentShift=v!)),const SizedBox(height:10),Chip(label:Text('ใบเตือนสะสม ${s.warnings} ครั้ง'),backgroundColor:warningColor(s.warnings).withOpacity(.15),labelStyle:TextStyle(color:warningColor(s.warnings),fontWeight:FontWeight.bold))])))),const SizedBox(height:20),Card(color:Colors.red[50],child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('⚠️ ฟอร์มออกใบเตือนดิจิทัล',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:15),DropdownButtonFormField<String>(decoration:const InputDecoration(labelText:'เลือกพนักงานที่ทำผิด',border:OutlineInputBorder()),value:selectedEmp,items:staffList.map((s)=>DropdownMenuItem(value:s.id,child:Text(s.name))).toList(),onChanged:(v)=>setState(()=>selectedEmp=v)),const SizedBox(height:15),DropdownButtonFormField<String>(decoration:const InputDecoration(labelText:'ประเภทความผิด',border:OutlineInputBorder()),value:offenseType,items:offenses.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>offenseType=v!)),const SizedBox(height:15),TextField(controller:descriptionController,maxLines:3,decoration:const InputDecoration(labelText:'รายละเอียดพฤติกรรม',border:OutlineInputBorder(),filled:true,fillColor:Colors.white)),const SizedBox(height:15),ElevatedButton.icon(onPressed:(){if(selectedEmp==null||descriptionController.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('❌ กรุณาเลือกพนักงานและระบุรายละเอียดความผิด'),backgroundColor:Colors.red));return;}final s=staffList.firstWhere((x)=>x.id==selectedEmp);setState(()=>s.warnings++);descriptionController.clear();ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('⚠️ ออกใบเตือนให้ ${s.name} แล้ว'),backgroundColor:Colors.orange[800]));},icon:const Icon(Icons.warning),label:const Text('บันทึกและออกใบเตือน'),style:ElevatedButton.styleFrom(backgroundColor:Colors.red[600],foregroundColor:Colors.white,padding:const EdgeInsets.all(14)))])))]));}
