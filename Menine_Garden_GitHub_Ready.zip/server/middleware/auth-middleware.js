const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'GARDEN_SUPER_SECRET_KEY_2026';
function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(403).json({ success: false, message: '❌ ไม่พบ Authorization Header' });
  const token = authHeader.split(' ')[1];
  if (!token) return res.status(403).json({ success: false, message: '❌ ไม่พบ Token' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); } catch (err) { return res.status(401).json({ success: false, message: '❌ Token ไม่ถูกต้องหรือหมดอายุ' }); }
}
function requireRole(role) { return (req, res, next) => { if (!req.user || req.user.role !== role) return res.status(403).json({ success: false, message: `❌ ต้องมีสิทธิ์ ${role}` }); next(); }; }
function requireAnyRole(roles = []) { return (req, res, next) => { if (!req.user || !roles.includes(req.user.role)) return res.status(403).json({ success: false, message: '❌ ไม่มีสิทธิ์เข้าถึง' }); next(); }; }
module.exports = { verifyToken, requireRole, requireAnyRole, JWT_SECRET };
