const express = require('express');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const { verifyToken, requireAnyRole, JWT_SECRET } = require('./middleware/auth-middleware');

const app = express();
app.use(express.json());
app.use(cors());

// ===================== In-Memory Database =====================
let timeLogs = [];
let checkOutLogs = [];
let cashRequests = [];
let equipmentRequests = [];
let accountingTransactions = [];
let workReports = [];
let payrollRecords = [];

let equipmentStock = {
  EQ001: { name: 'ปุ๋ยเคมี', qty: 50, unit: 'กระสอบ' },
  EQ002: { name: 'กรรไกรตัดกิ่ง', qty: 10, unit: 'อัน' },
};

const users = [
  { id: 'ADMIN001', username: 'admin', password: '1234', role: 'ADMIN', name: 'ผู้บริหารระบบ' },
  { id: 'ADMIN01', username: 'admin_garden', password: 'supersecure2026', role: 'ADMIN', name: 'ผู้บริหารระบบ' },
  { id: 'HR001', username: 'hr', password: '1234', role: 'HR', name: 'เจ้าหน้าที่ HR' },
  { id: 'MN005', username: 'pat', password: '1234', role: 'GARDENER', name: 'แพท' },
  { id: 'MN006', username: 'git', password: '1234', role: 'GARDENER', name: 'กิต' },
  { id: 'EMP001', username: 'EMP001', password: '123456', role: 'GARDENER', name: 'นายสมชาย ใจดี' },
];

function assertGardener(req, res, next) {
  if (req.user.role !== 'GARDENER') {
    return res.status(403).json({ success: false, message: 'สิทธิ์ไม่ถูกต้อง ต้องเป็นพนักงานคนสวน' });
  }
  next();
}

function calculateLateMinutes(clockInTime) {
  const [hour, min] = String(clockInTime).split(':').map(Number);
  if (Number.isNaN(hour) || Number.isNaN(min)) return 0;
  return Math.max(hour * 60 + min - 8 * 60, 0);
}

function isInProjectArea(lat, lng) {
  const projectLat = 13.75;
  const projectLng = 100.50;
  const distance = Math.sqrt(Math.pow(Number(lat) - projectLat, 2) + Math.pow(Number(lng) - projectLng, 2));
  return distance <= 0.01;
}

// ===================== Auth =====================
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);

  if (!user) {
    return res.status(401).json({ success: false, message: '❌ Username หรือ Password ไม่ถูกต้อง' });
  }

  const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: user.role === 'GARDENER' ? '30d' : '12h' });

  res.json({
    success: true,
    token,
    role: user.role.toLowerCase(),
    name: user.name,
    user: { id: user.id, role: user.role, name: user.name },
  });
});

// ===================== Gardener Mobile APIs =====================
// รองรับ payload ล่าสุด:
// { "employeeId": "EMP001", "clockInTime": "08:25", "lat": 13.7512, "lng": 100.5008 }
// employeeId ใน body จะใช้เพื่อ debug เท่านั้น ระบบใช้ req.user.id จาก JWT เป็นหลักเพื่อกันฝากเครื่องลงเวลา
app.post('/api/gardener/clockin', verifyToken, assertGardener, (req, res) => {
  const { employeeId, clockInTime, lat, lng } = req.body;

  if (!clockInTime || lat === undefined || lng === undefined) {
    return res.status(400).json({ success: false, message: 'กรุณาส่ง clockInTime, lat, lng ให้ครบ' });
  }

  if (!isInProjectArea(lat, lng)) {
    return res.status(400).json({ success: false, message: '❌ คุณอยู่นอกพื้นที่สวน ไม่สามารถลงเวลาได้' });
  }

  const lateMinutes = calculateLateMinutes(clockInTime);
  const logEntry = {
    id: 'TIME_' + Date.now(),
    employeeId: req.user.id,
    requestedEmployeeId: employeeId || null,
    employeeName: req.user.name,
    clockInTime,
    lateMinutes,
    lateDeduction: lateMinutes,
    gpsLat: Number(lat),
    gpsLng: Number(lng),
    gpsStatus: 'IN_RANGE',
    shift: '08:00-17:00',
    payrollStatus: lateMinutes > 0 ? 'late' : 'normal',
    status: lateMinutes > 0 ? 'late' : 'normal',
    date: new Date().toISOString().split('T')[0],
  };

  timeLogs.push(logEntry);

  res.json({
    success: true,
    message: `✅ บันทึกเวลาสำเร็จ (สาย ${lateMinutes} นาที)`,
    data: logEntry,
  });
});

// route เก่า คงไว้เพื่อไม่ให้ Flutter/ระบบเดิมพัง
app.post('/api/timeclock', verifyToken, (req, res) => {
  req.url = '/api/gardener/clockin';
  return app._router.handle(req, res);
});

app.post('/api/gardener/checkout', verifyToken, assertGardener, (req, res) => {
  const { clockOutTime } = req.body;
  const log = {
    id: 'OUT_' + Date.now(),
    employeeId: req.user.id,
    employeeName: req.user.name,
    clockOutTime,
    date: new Date().toISOString().split('T')[0],
  };
  checkOutLogs.push(log);
  res.json({ success: true, message: '✅ ลงเวลาออกงานสำเร็จ', data: log });
});

app.post('/api/gardener/report', verifyToken, assertGardener, (req, res) => {
  const { beforeImage, afterImage, detail } = req.body;
  const report = {
    id: 'REP' + Date.now(),
    employeeId: req.user.id,
    employeeName: req.user.name,
    beforeImage,
    afterImage,
    detail,
    createdAt: new Date().toISOString(),
  };
  workReports.push(report);
  res.json({ success: true, message: '📸 ส่งรายงานงานสำเร็จ', data: report });
});

app.post('/api/gardener/cash-request', verifyToken, assertGardener, (req, res) => {
  const { amount, reason } = req.body;
  const newRequest = {
    id: 'REQ-CASH-' + Date.now(),
    employeeId: req.user.id,
    employeeName: req.user.name,
    amount: Number(amount),
    reason,
    status: 'pending',
    date: new Date().toISOString().split('T')[0],
  };
  cashRequests.push(newRequest);
  res.json({ success: true, message: '💵 ส่งคำขอเบิกเงินสดแล้ว รอการอนุมัติ', data: newRequest });
});

// route เก่า คงไว้
app.post('/api/cash-request', verifyToken, (req, res) => {
  req.url = '/api/gardener/cash-request';
  return app._router.handle(req, res);
});

app.post('/api/equipment-request', verifyToken, (req, res) => {
  const { itemId, qty } = req.body;
  const item = equipmentStock[itemId];
  if (!item) return res.status(404).json({ success: false, message: 'ไม่พบอุปกรณ์ในคลัง' });

  const newRequest = {
    id: 'REQ-EQ-' + Date.now(),
    employeeId: req.user.id,
    employeeName: req.user.name,
    itemId,
    itemName: item.name,
    qty: Number(qty),
    status: 'pending',
    date: new Date().toISOString().split('T')[0],
  };
  equipmentRequests.push(newRequest);
  res.json({ success: true, message: '📦 ส่งคำขอเบิกอุปกรณ์แล้ว รอแอดมินอนุมัติ', data: newRequest });
});

// ===================== Admin APIs =====================
app.get('/api/admin/dashboard', verifyToken, requireAnyRole(['ADMIN', 'HR', 'SUPERVISOR']), (req, res) => {
  res.json({ success: true, user: req.user, timeLogs, checkOutLogs, cashRequests, equipmentRequests, equipmentStock, accountingTransactions });
});

app.get('/api/admin/full-dashboard', verifyToken, requireAnyRole(['ADMIN', 'HR', 'SUPERVISOR']), (req, res) => {
  res.json({
    success: true,
    summary: {
      totalClockIns: timeLogs.length,
      totalCheckOuts: checkOutLogs.length,
      totalReports: workReports.length,
      totalCashRequests: cashRequests.length,
      totalEquipmentRequests: equipmentRequests.length,
      totalLateDeductionToday: timeLogs.reduce((sum, x) => sum + (x.lateDeduction || 0), 0),
    },
    timeLogs,
    checkOutLogs,
    workReports,
    cashRequests,
    equipmentRequests,
    equipmentStock,
    accountingTransactions,
  });
});

app.get('/api/admin/payroll-preview', verifyToken, requireAnyRole(['ADMIN', 'HR']), (req, res) => {
  res.json({ success: true, payrollRecords, timeLogs });
});

app.post('/api/admin/approve-cash/:requestId', verifyToken, requireAnyRole(['ADMIN', 'HR']), (req, res) => {
  const request = cashRequests.find(item => item.id === req.params.requestId);
  if (!request) return res.status(404).json({ success: false, message: 'ไม่พบคำขอเบิกเงินสด' });

  request.status = 'approved';
  const transaction = {
    transactionId: 'TXN_' + Date.now(),
    type: 'expense',
    category: 'ซื้อของหน้างานด่วน',
    amount: request.amount,
    description: `เบิกเงินสดโดย ${request.employeeId}: ${request.reason}`,
    date: new Date().toISOString().split('T')[0],
  };
  accountingTransactions.push(transaction);
  res.json({ success: true, message: `💵 อนุมัติเงินสด ${request.amount} บาท สำเร็จ`, accounting_record: transaction });
});

app.post('/api/admin/approve-equipment/:requestId', verifyToken, requireAnyRole(['ADMIN', 'SUPERVISOR']), (req, res) => {
  const request = equipmentRequests.find(item => item.id === req.params.requestId);
  if (!request) return res.status(404).json({ success: false, message: 'ไม่พบคำขอเบิกอุปกรณ์' });

  const item = equipmentStock[request.itemId];
  if (!item || item.qty < request.qty) {
    return res.status(400).json({ success: false, message: `❌ สต็อกไม่พอ คงเหลือ ${item ? item.qty : 0}` });
  }

  item.qty -= request.qty;
  request.status = 'approved';
  res.json({ success: true, message: `✅ อนุมัติ ${request.id} สำเร็จ ตัดยอด ${request.itemName} ${request.qty} ${item.unit} คงเหลือ ${item.qty}`, data: request });
});

// ===================== Health/Test =====================
app.get('/api/health', (_req, res) => {
  res.json({ success: true, message: 'MENINE GARDEN API พร้อมใช้งาน' });
});

app.listen(3000, () => console.log('🚀 MENINE GARDEN Server running on port 3000'));
