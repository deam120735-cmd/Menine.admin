MENINE GARDEN HRMS READY PACKAGE

ในชุดนี้มี:
1) Flutter App: lib/main.dart
2) Node API: server/server.js
3) Auth Middleware: server/middleware/auth-middleware.js
4) ตัวอย่างยิง API: server/test-requests.http

วิธีรัน Backend:
cd server
npm install
npm start

ทดสอบ Backend:
GET http://localhost:3000/api/health

Login คนสวน:
POST http://localhost:3000/api/auth/login
{
  "username": "EMP001",
  "password": "123456"
}

Clock-In Payload ล่าสุด:
POST http://localhost:3000/api/gardener/clockin
Authorization: Bearer <TOKEN>
{
  "employeeId": "EMP001",
  "clockInTime": "08:25",
  "lat": 13.7512,
  "lng": 100.5008
}

ผลที่ควรได้: สาย 25 นาที / หัก 25 บาท / GPS IN_RANGE

Login Admin:
username: admin_garden
password: supersecure2026

Login Flutter ทดสอบในแอป:
MN006 / 123456
ADMIN / 0000

หมายเหตุ:
- Backend ตอนนี้ใช้ In-Memory Database ข้อมูลจะหายเมื่อ restart server
- พร้อมต่อ Supabase/PostgreSQL ภายหลัง
